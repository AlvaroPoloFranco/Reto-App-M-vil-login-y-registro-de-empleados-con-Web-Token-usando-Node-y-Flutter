const boom = require('@hapi/boom');
const joi = require('@hapi/joi');
var winston = require('../services/logger');
var logger = winston.logger;

function validate(data, schema) {
    const { error } = joi.validate(data, schema);
    return error;
}

function validationHandler(schema, check = 'body') {
    return function(req, res, next) {
        const error = validate(req[check], schema);
        error ? next(boom.badRequest(error)) : next();
        logger.error(error, { timestamp: new Date() });
    };
}

module.exports = validationHandler;
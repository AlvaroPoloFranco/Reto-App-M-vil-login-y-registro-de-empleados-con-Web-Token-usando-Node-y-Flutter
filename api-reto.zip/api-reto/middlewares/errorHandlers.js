const boom = require('@hapi/boom');
const { config } = require('../config/config');
var winston = require('../services/logger');
var logger = winston.logger;


function withErrorStack(error, stack) {
    if (config.dev) {
        return {...error, stack };
    }
    logger.error(error, { timestamp: new Date() });
    return error;
}

function logErrors(err, req, res, next) {
    console.log(err);
    logger.error(err, { timestamp: new Date() });
    next(err);
}

function wrapErrors(err, req, res, next) {
    if (!err.isBoom) {
        next(boom.badImplementation(err));
    }
    logger.error(err, { timestamp: new Date() });
    next(err);
}

function errorHandler(err, req, res, next) { // eslint-disable-line
    const {
        output: { statusCode, payload }
    } = err;
    logger.error(err, { timestamp: new Date() });
    res.status(statusCode);
    res.json(withErrorStack(payload, err.stack.err));
}

module.exports = {
    logErrors,
    wrapErrors,
    errorHandler
};
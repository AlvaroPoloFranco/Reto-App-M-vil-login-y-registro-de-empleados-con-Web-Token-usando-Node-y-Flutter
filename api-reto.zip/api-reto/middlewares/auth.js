var services = require('../services');


function isAuth(req, res, next) {
    var token = req.headers.authorization;

    if (!token) {
        return res.status(403).send({ 'success': false, 'msg_error': 'Usted no tiene autorización.' });
    }

    var code = req.headers.authorization.split(' ')[1];

    services.decodeToken(code).then(response => {
        req.user = response
        next()
    }).catch(response => {
        res.status(401).send({ 'success': false, 'msg_error': 'Sesión expirada, por favor vuelva a iniciar sesión.' });
    });
}

module.exports = isAuth
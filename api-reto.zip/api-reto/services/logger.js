var winston = require('winston');
var moment = require('moment');


const timestamp = function () {
  const d = new Date();
  var year = d.getFullYear();
  var month = ("0" + (d.getMonth() + 1)).slice(-2);
  var day = ("0" + d.getDate()).slice(-2);
  var hour = ("0" + d.getHours()).slice(-2);
  var minute = ("0" + d.getMinutes()).slice(-2);
  var second = ("0" + d.getSeconds()).slice(-2);
  var milisecond = d.getMilliseconds();

  return year + `-` + month + `-` + day + ` ` + hour + `:` + minute + `:` + second + `m` + milisecond;
};

const tsFormat = () => (new Date()).toLocaleDateString() + ' - ' + (new Date()).toLocaleTimeString();

var logger = new (winston.Logger)({
  transports: [
    new (winston.transports.Console)(),
    new (winston.transports.File)({
      filename: 'log/error.log',
      timestamp: timestamp
    })
  ]
});

var loggerErrorServicesTwiins = new (winston.Logger)({
  transports: [
    new (winston.transports.Console)(),
    new (winston.transports.File)({
      filename: './log/error.log',
      timestamp: timestamp
    })
  ]
});

var loggerSuccessServicesTwiins = new (winston.Logger)({
  transports: [
    new (winston.transports.Console)(),
    new (winston.transports.File)({
      filename: './log/success.log',
      timestamp: timestamp
    })
  ]
});

function logError(mensaje) {
  const horaActual = moment().format('YYYY-MM-DD HH:mm:ss')
  loggerErrorServicesTwiins.error({ timestamp: horaActual, message: mensaje });
}

function logSuccess(mensaje) {
  const horaActual = moment().format('YYYY-MM-DD HH:mm:ss')
  loggerSuccessServicesTwiins.info({ timestamp: horaActual, message: mensaje });
}


module.exports = {
  logger,
  logError,
  logSuccess
}

const boom = require('@hapi/boom');
const e = require('express');
const sequelize = require('../models/modelEmpleado');

class EmpleadoService {
  constructor() { }

  async create(data) {
    return data;
  }

  async obtenerEmpleados() {
    const query = 'SELECT * FROM public.empleado ORDER BY emp_cedula ASC';
    const [data, metadata] = await sequelize.sequelize.query(query);
    // const data1= {emp_cedula:"1104354574",emp_nombres:"Yadira",emp_apellidos:"Granda",emp_correo:"aaa@ss.com"}
    // const newCategory = await sequelize.Empleado.create(data1);
    return data;
  }

  async crearEmpleado(Empleado) {
    console.log(this.getRandomString(5))
    const data = { emp_cedula: Empleado.empCedula, emp_nombres: Empleado.empNombres, emp_apellidos: Empleado.empApellidos, emp_correo: Empleado.empCorreo, emp_activo: true }
    const newCategory = await sequelize.Empleado.create(data);
    const usuario1 = {
      usu_correo: Empleado.empCorreo,
      usu_password: this.getRandomString(5),
      usu_fecha_creacion: new Date(),
      usu_activo: true
    }
    if (newCategory) {
      const usuario = await sequelize.Usuario.create(usuario1);
      console.log(usuario)
    }
    return newCategory;
  }

  async buscarEmpleado(empCedula) {
    const device = await sequelize.Empleado.findOne({
      where: {
        emp_cedula: empCedula
      }
    });
    if (!device) {
      return 'Empleado no encontrado.'
    }
    return device.dataValues
  }

  getRandomString(length) {
    var randomChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var result = '';
    for (var i = 0; i < length; i++) {
      result += randomChars.charAt(Math.floor(Math.random() * randomChars.length));
    }
    return result;
  }

  async login(correo, password) {
    const device = await sequelize.Usuario.findOne({
      where: {
        usu_correo: correo,
        usu_password: password,
        usu_activo: true
      }
    });
    if (!device) {
      return 'Error en el usuario o password.'
    }
    return device.dataValues
  }

  // async delete(id) {
  //   return { id };
  // }
}

module.exports = EmpleadoService;

const leftPad = require('left-pad');
var moment = require('moment');
const requestIp = require('request-ip');

var dateFormat = require('dateformat');
dateFormat.i18n = {
    dayNames: [
        'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat',
        'Dom', 'Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab'
    ],
    monthNames: [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
        'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dec'
    ],
    timeNames: [
        'a', 'p', 'am', 'pm', 'A', 'P', 'AM', 'PM'
    ]
};


function getNestedChildren(arr, parent) {
    var out = []
    for (var i in arr) {
        if (arr[i].codigoPadre == parent) {
            var children = getNestedChildren(arr, arr[i].codigo)

            if (children.length) {
                arr[i].children = children
            }
            out.push(arr[i])
        }
    }
    return out
}

function generarNumeroTurno(prefijo, numero) {
    if (!prefijo)
        prefijo = '';
    return prefijo + '-' + leftPad(numero, 5, 0);
}

function formatDateTime(fecha_string) {
    var date = new Date(fecha_string);
    var date_format = dateFormat(date, "dddd, dd mmmm yyyy, h:MM TT");
    return date_format;
}

function dateDiffSeconds(date_start, date_end) {
    var ds = moment(date_start);
    var de = moment(date_end);
    var duration = moment.duration(de.diff(ds));
    return parseInt(duration.asSeconds());
}

function formatDateSeconds(seconds) {
    var result = '';
    var minutes = 0;
    var int = 0;
    var mod = 0;
    var seg = 0;
    var hours = 0;
    var days = 0;
    var palabra = '';
    if (seconds < 60) {
        result = seconds + ' segundos.';
    }
    else if (seconds >= 60 && seconds < 3600) {
        seg = parseInt(seconds % 60);
        minutes = parseInt(seconds / 60);
        if (minutes > 1)
            palabra = 'minutos';
        else
            palabra = 'minuto';

        result = minutes + ' ' + palabra + ' y ' + seg + ' segundos.';
    }
    else if (seconds >= 3600 && seconds < 86400) {
        minutes = seconds / 60;
        mod = parseInt(minutes) % 60;
        hours = parseInt(minutes / 60);

        if (hours > 1)
            palabra = 'horas';
        else
            palabra = 'hora';

        if (mod > 0)
            result = hours + ' ' + palabra + ' y ' + mod + ' minutos aproximadamente.';
        else
            result = hours + ' ' + palabra + '.';
    }
    else //if( seconds >= 86400 )
    {
        hours = seconds / 60 / 60;
        mod = parseInt(hours) % 24;
        days = parseInt(hours / 24);

        if (days > 1)
            palabra = 'días';
        else
            palabra = 'día';

        if (mod > 0)
            result = days + ' ' + palabra + ' y ' + mod + ' horas aproximadamente.';
        else
            result = days + ' ' + palabra + '.';
    }
    return result;
}

/*
 * Valida que la diferencia entre fechas sea mayor a los anios
 * formato fecha_anterior dd/mm/YYYY, fecha_actual = new Date()
 * */
function validarEdad(fecha_anterior, fecha_actual, anios) {
    var vec_date = fecha_anterior.split('/');
    var day = parseInt(vec_date[0]);
    var month = parseInt(vec_date[1]) - 1;
    var year = parseInt(vec_date[2]);

    var current_day = fecha_actual.getDate();
    var current_month = fecha_actual.getMonth();
    var current_year = fecha_actual.getFullYear();

    var date_ant = moment([current_year, current_month, current_day]);
    var current_date = moment([year, month, day]);

    var duration = (date_ant.diff(current_date, 'years'));
    var years_diff = parseInt(duration);
    if (years_diff < anios) {
        return false;
    }
    return true;
}
/*
 * funcion para buscar el horario en el cual puede solicitar ayuda
 */
function buscarHorario(arrayHorario) {
    var tam = arrayHorario.length;
    var i = 0;
    var horario = '';
    for (i = 0; i < tam; i++) {
        horario = arrayHorario[i].esta_en_horario;
        if (horario === 'SI')
            return horario;
    }
    return horario;
}
/*
 * Formatear IP que se obtiene del cliente
 */
function getFormatIp(req) {
    var ip = '';
    var clientIp = requestIp.getClientIp(req);// me otiene de esta manera -> ::ffff:192.168.236.245
    var tam_ip = clientIp.length;
    if (tam_ip > 15)
        ip = clientIp.substring(7, tam_ip);
    return ip.trim();
}

function crearArchivoTextoLog(proceso ,mensaje, tipo) {
    const data = {
        proceso: proceso,
        tipo: tipo,
        mensaje: mensaje
    };
    return data;
}

module.exports = {
    getNestedChildren,
    generarNumeroTurno,
    formatDateTime,
    dateDiffSeconds,
    formatDateSeconds,
    validarEdad,
    buscarHorario,
    getFormatIp,
    crearArchivoTextoLog
}
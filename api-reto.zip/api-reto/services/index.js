var jwt = require('jwt-simple');
var moment = require('moment');
var vars = require('../config/vars');


function createToken(user) {
    var payload = {
        sub: user, //genera despues de guardar en la bdd
        iat: moment().unix(), //cuando fue creado el token
        exp: moment().add(30, 'days').unix() //expiracion token
    }

    return jwt.encode(payload, vars.SECRET_TOKEN);
}

function decodeToken(token) {
    var decoded = new Promise((resolve, reject) => {
        try {
            var payload = jwt.decode(token, vars.SECRET_TOKEN);
            if (payload.exp <= moment.unix()) {
                reject({
                    status: 401,
                    message: 'El token ha expirado'
                });
            }

            resolve(payload.sub)
        } catch (error) {
            reject({
                status: 500,
                message: 'Invalid Token'
            });

        }
    });
    return decoded;
}

module.exports = {
    createToken,
    decodeToken
}
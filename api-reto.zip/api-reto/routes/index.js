var express = require('express');
var router = express.Router();
var auth = require('../middlewares/auth');
var api = require('../controllers/api');
var RouterLogeo = require('../routes/routesLogeo');
var RouterAdministracion = require('../routes/routesAdministacionUsuarios');

//Constante de verificación de rutas

const {
    logErrors,
    wrapErrors,
    errorHandler
} = require('../middlewares/errorHandlers');

const notFoundHandler = require('../middlewares/notFoundHandler');


/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('index', { title: 'Api Reto - Interfaz Administración' });
});

// Rutas

RouterLogeo(router);
RouterAdministracion(router);

// body parser
router.use(express.json());
// Catch 404
router.use(notFoundHandler);

// Errors middleware - manejadores de errores
router.use(logErrors);
router.use(wrapErrors);
router.use(errorHandler);




function sleep(time) {
    return new Promise((resolve) => setTimeout(resolve, time));
}


module.exports = router;
//Librerías para la gestión de usuarios
const express = require('express');
var isAuth = require('../middlewares/auth');
const UserService = require('../services/empleado.service');
const service = new UserService();


//Midelware para validar los campos de los json de peticiones
const validationHandler = require('../middlewares/validationHandler');

const {
    crearEmpleado
} = require('../models/inputEmpleado');

const {
    loginUsuario
} = require('../models/inputUsuarios');


function routesAdministacionUsuarios(app) {

    const router = express.Router();

    app.use('/reto', router);

    router.post('/obtenerEmpleados', isAuth, async function (req, res, next) {
        const category = await service.obtenerEmpleados()
        res.json(category);
    });

    router.post('/crearEmpleado', isAuth, validationHandler(crearEmpleado), async function (req, res, next) {
        try {
            const { body: data } = req;
            const datos = await service.crearEmpleado(data)
            if (datos) {
                res.status(200).send({ success: true, Empleado: datos });
            } else {
                res.status(404).send({ success: false, msg_error: "Servicio no disponible. Vuelva a intentarlo más tarde." });
            }
        } catch (error) {
            res.status(404).send({ success: false, msg_error: "Error al guardar el Empleado: El empleado ya existe." });
        }
    });

    router.post('/actualizarEmpleado', isAuth, validationHandler(crearEmpleado), async function (req, res, next) {

    });

    router.post('/buscarEmpleado', isAuth, validationHandler(crearEmpleado), async function (req, res, next) {
        const { body: data } = req;
        const datos = await service.buscarEmpleado(data.empCedula)
        if (datos) {
            if (datos == 'Empleado no encontrado.') {
                res.status(200).send({ success: false, Empleado: datos });
            } else {
                res.status(200).send({ success: true, Empleado: datos });
            }
        } else {
            res.status(404).send({ success: false, msg_error: "Servicio no disponible. Vuelva a intentarlo más tarde." });
        }
    });

    router.post('/login', isAuth, validationHandler(loginUsuario), async function (req, res, next) {
        const { body: data } = req;
        const datos = await service.login(data.usuario, data.password)
        if (datos) {
            if (datos == 'Error en el usuario o password.') {
                res.status(200).send({ success: false, usuario: datos });
            } else {
                res.status(200).send({ success: true, usuario: 'OK' });
            }
        } else {
            res.status(404).send({ success: false, msg_error: "Servicio no disponible. Vuelva a intentarlo más tarde." });
        }
    });
}



module.exports = routesAdministacionUsuarios;
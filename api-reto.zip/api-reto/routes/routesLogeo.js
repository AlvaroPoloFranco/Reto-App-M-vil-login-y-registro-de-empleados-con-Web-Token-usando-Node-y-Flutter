const express = require('express');
var auth = require('../middlewares/auth');
var jwt = require("jsonwebtoken");
var vars = require('../config/vars');

const {
    consultarUsuario
} = require('../models/usuarios');

const validationHandler = require('../middlewares/validationHandler');


function routesLogeo(app) {

    const router = express.Router();

    app.use('/usuarios', router);

    router.post('/login', validationHandler(consultarUsuario), async function (req, res, next) {
        const { body: data } = req;
        var username = data.usuario;
        var password = data.password;
        try {
            if (!((username == "apolo" && password == "PruebaReto2021"))) {
                res.status(200).send({
                    success: false,
                    msg_error: "001",
                    msg: "Usuario o contraseña inválidos"
                });
                return;
            } else {
                var tokenData = {
                    username: username
                    // ANY DATA
                };

                var token = jwt.sign(tokenData, vars.SECRET_TOKEN, {
                    expiresIn: 60 * 60 * 24 // expires in 24 hours
                });

                res.status(200).send(await { token });
            }
        } catch (err) {
            next(err.details[0].message);
        }
    });

}

module.exports = routesLogeo;
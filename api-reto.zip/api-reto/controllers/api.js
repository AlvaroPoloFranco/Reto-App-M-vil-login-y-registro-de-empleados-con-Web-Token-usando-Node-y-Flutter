const express = require('express');

async function clock(req, res) {
    var date = new Date();
    var current_hour = date.getHours();
    var current_minute = date.getMinutes();
    var current_second = date.getSeconds();
    res.status(200).send(await { hora: current_hour, minuto: current_minute, segundo: current_second });
}

module.exports = {
    clock
}

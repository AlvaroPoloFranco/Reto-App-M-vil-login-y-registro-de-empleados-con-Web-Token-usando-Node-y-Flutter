const joi = require('@hapi/joi');

const usuario = joi.string().min(4).max(120).required().email().error(errors => {
    errors.forEach(err => {
        switch (err.type) {
            case "any.required":
                err.message = "El usuario es requerido";
                break;
            case "any.empty":
                err.message = "El usuario no debe estar vacío";
                break;
            case "string.min":
                err.message = `El usuario debe contener mínimo ${err.context.limit} caracteres`;
                break;
            case "string.max":
                err.message = `El usuario debe contener máximo ${err.context.limit} caracteres`;
                break;
            case "string.email":
                err.message = `El usuario es incorrecto`;
                break;
            default:
                break;
        }
    });
    return errors;
});

const password = joi.string().min(4).max(8).required().error(errors => {
    errors.forEach(err => {
        switch (err.type) {
            case "any.required":
                err.message = "El password es requerido";
                break;
            case "any.empty":
                err.message = "El password no debe estar vacío";
                break;
            case "string.min":
                err.message = `El password debe contener mínimo ${err.context.limit} caracteres`;
                break;
            case "string.max":
                err.message = `El password debe contener máximo ${err.context.limit} caracteres`;
                break;
            case "string.email":
                err.message = `El password es incorrecto`;
                break;
            default:
                break;
        }
    });
    return errors;
});

const loginUsuario = {
    usuario: usuario.required(),
    password: password.required()
}

module.exports = {
    loginUsuario
}
const bd = require('../config/databases');
const { Sequelize, DataTypes } = require('sequelize');
const host = bd.conn_api_reto.server;
const port = bd.conn_api_reto.port;
const db = {}

const sequelize = new Sequelize(bd.conn_api_reto.database, bd.conn_api_reto.user, bd.conn_api_reto.password, {
  host,
  port,
  dialect: 'postgres',
  logging: true
})

var Empleado = sequelize.define('empleado', {
  emp_cedula: { type: Sequelize.STRING, primaryKey: true, allowNull: false },
  emp_nombres: { type: Sequelize.STRING },
  emp_apellidos: { type: Sequelize.STRING },
  emp_correo: { type: Sequelize.STRING },
  emp_activo: { type: Sequelize.BOOLEAN }
}, {
  tableName: 'empleado',
  timestamps: false
});

var Usuario = sequelize.define('usuario', {
  usu_correo: { type: Sequelize.STRING, primaryKey: true, allowNull: false },
  usu_password: { type: Sequelize.STRING },
  usu_fecha_creacion: { type: DataTypes.DATE },
  usu_activo: { type: Sequelize.BOOLEAN }
}, {
  tableName: 'usuario',
  timestamps: false
});

db.sequelize = sequelize
db.Sequelize = Sequelize
db.Empleado = Empleado
db.Usuario = Usuario

module.exports = db

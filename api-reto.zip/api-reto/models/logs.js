const Sequelize = require('sequelize');
var db_conections = require('../config/databases');


var server = db_conections.conn_logs.server;
var database = db_conections.conn_logs.database;
var user = db_conections.conn_logs.user;
var password = db_conections.conn_logs.password;

const conn_logs = new Sequelize(database, user, password, {
    host: server,
    dialect: 'postgres',
    operatorsAliases: false
        //  timezone: '-05:00'//para que funcionen correctamente las consultas con fechas
});
const joi = require('@hapi/joi');

const empCedula = joi.string().min(4).max(20).required().error(errors => {
    errors.forEach(err => {
        switch (err.type) {
            case "any.required":
                err.message = "El empCedula es requerido";
                break;
            case "any.empty":
                err.message = "El empCedula no debe estar vacío";
                break;
            case "string.min":
                err.message = `El empCedula debe contener mínimo ${err.context.limit} caracteres`;
                break;
            case "string.max":
                err.message = `El empCedula debe contener máximo ${err.context.limit} caracteres`;
                break;
            default:
                break;
        }
    });
    return errors;
});

const empNombres = joi.string().min(4).max(60).required().error(errors => {
    errors.forEach(err => {
        switch (err.type) {
            case "any.required":
                err.message = "El empNombres es requerido";
                break;
            case "any.empty":
                err.message = "El empNombres no debe estar vacío";
                break;
            case "string.min":
                err.message = `El empNombres debe contener mínimo ${err.context.limit} caracteres`;
                break;
            case "string.max":
                err.message = `El empNombres debe contener máximo ${err.context.limit} caracteres`;
                break;
            default:
                break;
        }
    });
    return errors;
});

const empApellidos = joi.string().min(4).max(60).required().error(errors => {
    errors.forEach(err => {
        switch (err.type) {
            case "any.required":
                err.message = "El empApellidos es requerido";
                break;
            case "any.empty":
                err.message = "El empApellidos no debe estar vacío";
                break;
            case "string.min":
                err.message = `El empApellidos debe contener mínimo ${err.context.limit} caracteres`;
                break;
            case "string.max":
                err.message = `El empApellidos debe contener máximo ${err.context.limit} caracteres`;
                break;
            default:
                break;
        }
    });
    return errors;
});

const empCorreo = joi.string().min(4).max(240).required().email().error(errors => {
    errors.forEach(err => {
        switch (err.type) {
            case "any.required":
                err.message = "El empCorreo es requerido";
                break;
            case "any.empty":
                err.message = "El empCorreo no debe estar vacío";
                break;
            case "string.min":
                err.message = `El empCorreo debe contener mínimo ${err.context.limit} caracteres`;
                break;
            case "string.max":
                err.message = `El empCorreo debe contener máximo ${err.context.limit} caracteres`;
                break;
            case "string.email":
                err.message = `El empCorreo es incorrecto`;
                break;
            default:
                break;
        }
    });
    return errors;
});

const crearEmpleado = {
    empCedula: empCedula.required(),
    empNombres: empNombres.required(),
    empApellidos: empApellidos.required(),
    empCorreo: empCorreo.required()

}


module.exports = {
    crearEmpleado
}

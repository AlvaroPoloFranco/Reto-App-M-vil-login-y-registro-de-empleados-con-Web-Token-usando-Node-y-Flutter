const joi = require('@hapi/joi');

const usuario = joi.string().min(2).error(() => 'Mínimo 2 caracteres');
const password = joi.string().min(2).error(() => 'Mínimo 2 caracteres');

const consultarUsuario = {
    usuario: usuario.required(),
    password: password.required()
}

module.exports = {
    consultarUsuario
}
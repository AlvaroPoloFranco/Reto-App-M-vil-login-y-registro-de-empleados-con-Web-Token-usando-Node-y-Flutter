module.exports = {
    conn_api_reto: {
        server: 'localhost',
        database: 'api_reto',
        user: 'postgres',
        password: 'Api2022',
        dialect: "postgres",
        timezone: "America/Bogota",
        port:5432
    }
}
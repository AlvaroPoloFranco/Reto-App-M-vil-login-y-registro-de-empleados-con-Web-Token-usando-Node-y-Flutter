module.exports = {
    SECRET_TOKEN: 'ApiReto2021*'
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import 'package:provider/provider.dart';

import 'package:productos_app/services/services.dart';

import 'package:productos_app/ui/input_decorations.dart';
import 'package:productos_app/widgets/widgets.dart';

class EmpleadoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                ProductImage(),
                Positioned(
                    top: 60,
                    left: 20,
                    child: IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: Icon(
                        Icons.arrow_back_ios_new,
                        size: 40,
                        color: Colors.white,
                      ),
                    ))
              ],
            ),
            _EmpleadoForm(),
            SizedBox(height: 100),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.save_outlined),
        onPressed: () {},
      ),
    );
  }
}

class _EmpleadoForm extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        width: double.infinity,
        height: 1000,
        decoration: _buildBoxDecoration(),
        child: Form(
          child: Column(
            children: [
              SizedBox(height: 10),
              TextFormField(
                decoration: InputDecorations.authInputDecoration(
                    hintText: 'Cédula:', labelText: 'Cédula Empleado'),
              ),
              SizedBox(height: 30),
              TextFormField(
                decoration: InputDecorations.authInputDecoration(
                    hintText: 'Nombres:', labelText: 'Nombres Empleado'),
              ),
              SizedBox(height: 30),
              TextFormField(
                decoration: InputDecorations.authInputDecoration(
                    hintText: 'Apellidos:', labelText: 'Apellidos Empleado'),
              ),
              SizedBox(height: 30),
              TextFormField(
                decoration: InputDecorations.authInputDecoration(
                    hintText: 'Correo:', labelText: 'Correo Empleado'),
              ),
              SizedBox(height: 30),
              TextFormField(
                decoration: InputDecorations.authInputDecoration(
                    hintText: 'Fecha:', labelText: 'Fecha de Nacimiento'),
              ),
              SizedBox(height: 30),
              TextFormField(
                decoration: InputDecorations.authInputDecoration(
                    hintText: 'Dirección:', labelText: 'Dirección Domicilio'),
              ),
              SizedBox(height: 30),
              TextFormField(
                decoration: InputDecorations.authInputDecoration(
                    hintText: 'Celular:', labelText: 'Teléfono Celular'),
              ),
              SizedBox(height: 30),
              SwitchListTile(
                  value: true,
                  title: Text('Vaunación'),
                  activeColor: Colors.indigo,
                  onChanged: (value) {
                    //NUevo valor
                  }),
              SizedBox(height: 30),
              TextFormField(
                decoration: InputDecorations.authInputDecoration(
                    hintText: 'Fecha Vac:', labelText: 'Fecha Vacunación'),
              ),
              SizedBox(height: 30),
              TextFormField(
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                      RegExp(r'^(\d+)?\.?\d{0,2}'))
                ],
                onChanged: (value) {},
                keyboardType: TextInputType.number,
                decoration: InputDecorations.authInputDecoration(
                    hintText: 'Dosis', labelText: 'Número de Dosis:'),
              ),
              SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  BoxDecoration _buildBoxDecoration() => BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
              bottomRight: Radius.circular(25),
              bottomLeft: Radius.circular(25)),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                offset: Offset(0, 5),
                blurRadius: 5)
          ]);
}

export 'package:productos_app/screens/check_auth_screen.dart';
export 'package:productos_app/screens/home_screen.dart';
export 'package:productos_app/screens/loading_screen.dart';
export 'package:productos_app/screens/login_screen.dart';
export 'package:productos_app/screens/product_screen.dart';
export 'package:productos_app/screens/register_screen.dart';
export 'package:productos_app/screens/empleado_screen.dart';

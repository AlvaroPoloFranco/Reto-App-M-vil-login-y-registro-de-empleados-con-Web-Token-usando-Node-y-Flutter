import 'package:flutter/material.dart';
import 'package:productos_app/models/models.dart';

class EmpleadoFormProvider extends ChangeNotifier {
  GlobalKey<FormState> formKey = new GlobalKey<FormState>();

  Empleados empleados;

  EmpleadoFormProvider(this.empleados);

  updateAvailability(bool value) {
    print(value);
    this.empleados.empActivo = value;
    notifyListeners();
  }

  bool isValidForm() {
    print(empleados.empApellidos + empleados.empNombres);
    print(empleados.empCedula);
    print(empleados.empActivo);

    return formKey.currentState?.validate() ?? false;
  }
}

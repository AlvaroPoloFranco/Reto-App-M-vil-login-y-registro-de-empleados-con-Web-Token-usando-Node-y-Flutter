import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import 'package:productos_app/models/models.dart';

class EmpleadoService extends ChangeNotifier {
  final String _baseUrlPrincipal = '192.168.1.4:3002';

  final List<Empleados> empleados = [];
  late Product selectedProduct;

  final storage = new FlutterSecureStorage();

  File? newPictureFile;

  bool isLoading = true;
  bool isSaving = false;

  EmpleadoService() {
    this.loadEmpleados();
  }

  Future<List<Empleados>> loadEmpleados() async {
    this.isLoading = true;
    notifyListeners();

    // final url = Uri.https( _baseUrl, 'products.json', {
    //   'auth': await storage.read(key: 'token') ?? ''
    // });
    // final resp = await http.get( url );

    // final Map<String, dynamic> productsMap = json.decode( resp.body );

    // productsMap.forEach((key, value) {
    //   final tempProduct = Product.fromMap( value );
    //   tempProduct.id = key;
    //   this.products.add( tempProduct );
    // });

    // this.isLoading = false;
    // notifyListeners();

    final Map<String, dynamic> authData = {
      "usuario": "apolo",
      "password": "PruebaReto2021"
    };
    final url = Uri.http(_baseUrlPrincipal, '/usuarios/login');
    var resp = await http.post(url, body: authData);
    final Map<String, dynamic> decodedResp = json.decode(resp.body);
    if (decodedResp.containsKey('token')) {
      print(decodedResp.containsKey('token'));
      final urlEmpleados =
          Uri.http(_baseUrlPrincipal, '/reto/obtenerEmpleados');
      var respLogin = await http.post(urlEmpleados, headers: {
        'Authorization': 'Bearer ' + decodedResp['token'].toString()
      });
      final Map<String, dynamic> empleadosMap = json.decode(respLogin.body);

      empleadosMap.forEach((key, value) {
        final tempEmpleados = Empleados.fromMap(value);
        tempEmpleados.empCedula = key;
        this.empleados.add(tempEmpleados);
      });
      print(this.empleados);
      this.isLoading = false;
      notifyListeners();
    }
    return this.empleados;
  }
}
